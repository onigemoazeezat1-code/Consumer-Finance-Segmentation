# Dataset instructions

Place the SCF 2019 compressed CSV file (`SCFP2019.csv.gz`) in this folder after obtaining it from the official Survey of Consumer Finances source.

The dataset is intentionally not included in this repository. Review the official data documentation, codebook, and terms before using or redistributing data. The notebook contains hard-coded paths that must be changed to a relative path such as `../data/SCFP2019.csv.gz` when the notebook is run from the `notebooks/` directory.
